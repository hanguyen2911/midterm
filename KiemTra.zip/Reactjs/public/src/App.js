
import './App.css';
import Sign_in from './Login';

import Register from './Register';



function App() {
  return (
    <div >
 
    <Register />
    <Sign_in />

   
    </div>
  );
}

export default App;
